﻿namespace WpfDotNetFrameworkWithFeatureFlags.FeatureManagement
{
    public interface IFeatureManagementBuilder
    {
    }
}