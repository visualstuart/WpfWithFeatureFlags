﻿using System;

namespace WpfDotNetFrameworkWithFeatureFlags
{
    public class Host
    {
        public IServiceProvider Services { get; set; }
    }
}
