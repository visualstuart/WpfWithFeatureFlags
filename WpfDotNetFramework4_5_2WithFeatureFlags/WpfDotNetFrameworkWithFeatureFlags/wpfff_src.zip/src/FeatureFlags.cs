﻿namespace WpfDotNetFrameworkWithFeatureFlags
{
    internal enum FeatureFlags
    {
        FeatureA,
        FeatureB,
        FeatureC
    }
}
